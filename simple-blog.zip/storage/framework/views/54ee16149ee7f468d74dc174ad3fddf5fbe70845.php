<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $__env->yieldContent('head.title'); ?></title>
	<link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="/css/style.css">
	<link rel="stylesheet" type="text/css" href="/css/admin.css">
	<?php echo $__env->yieldContent('head.css'); ?>
</head>
<body>
	<div class="wrapper">
		<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="container-fluid">
			<div class="col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2 col-lg-8 col-lg-offset-2">
				<div class="row">
					<div class="col-md-8 col-sm-6 col-lg-8">
						<?php echo $__env->yieldContent('body.content'); ?>
					</div>
					<div class="col-md-4 col-sm-6 col-lg-4">
						<?php echo $__env->yieldContent('body.content1'); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<script type="text/javascript" src="/js/jquery/jquery.js"></script>
		<script type="text/javascript" src="/js/bootstrap.min.js"></script>
		<?php echo $__env->yieldContent('body.js'); ?>
</body>
</html>