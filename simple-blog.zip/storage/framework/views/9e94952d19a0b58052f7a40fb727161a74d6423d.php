<?php $__env->startSection('head.title'); ?>
    Xem bài viết
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.content'); ?>
		<a href="/" style="text-decoration: none;" class="btn-link btn"><span class="glyphicon glyphicon-chevron-left" ></span> Quay lại</a>
        <h2 id="title"><?php echo e($articles->title); ?></h2>
        <p id="title"><?php echo e($articles->content); ?></p>
        <div style="margin-top: 40px;">
            <?php if(auth()->user() && (auth()->user()->admin == 1)): ?>
        		<a class="btn btn-primary" href="<?php echo e(route('articles.edit', $articles->id)); ?>" role="button">Chỉnh sửa bài viết</a>
        		<a class="btn btn-danger" href="<?php echo e(route('articles.delete', $articles->id)); ?>" role="button">Xóa bài viết</a>
        	<?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>