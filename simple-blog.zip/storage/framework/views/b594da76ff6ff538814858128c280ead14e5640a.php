<?php $__env->startSection('head.title'); ?>
    Trang chủ Blog
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.content'); ?>
    <?php foreach($articles as $a): ?>
        <h2><?php echo e($a->title); ?></h2>
        <p><?php echo e($a->content); ?></p>
        <a style="text-decoration: none;" href="<?php echo e(route('articles.show', $a->id)); ?>">Read more</a>
    <?php endforeach; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>