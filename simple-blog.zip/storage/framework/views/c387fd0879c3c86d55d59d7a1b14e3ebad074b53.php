<?php $__env->startSection('head.title'); ?>
    Trang chủ
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.content'); ?>
	<?php function catchuoi($chuoi,$gioihan){			
    if(strlen($chuoi)<=$gioihan)
    {
        return $chuoi;
    }
    else{  
        if(strpos($chuoi," ",$gioihan) > $gioihan){
            $new_gioihan=strpos($chuoi," ",$gioihan);
            $new_chuoi = substr($chuoi,0,$new_gioihan)."...";
            return $new_chuoi;
        }
        $new_chuoi = substr($chuoi,0,$gioihan)."...";
        return $new_chuoi;
    }
	}?>
    <?php foreach($articles as $a): ?>
        <h2 id="title"><?php echo e($a->title); ?></h2>
        <p id="title"><?php echo e(catchuoi($a->content,1000)); ?></p>
        <a style="text-decoration: none;" href="<?php echo e(route('articles.show', $a->id)); ?>">Read more</a>
    <?php endforeach; ?>

    <div style="margin-top: 50px;">
    	<?php echo e($articles->render()); ?>;
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>