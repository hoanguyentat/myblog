<?php $__env->startSection('head.title'); ?>
    Xem chu de
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.content'); ?>
		<a href="/" style="text-decoration: none;" class="btn-link btn"><span class="glyphicon glyphicon-chevron-left" ></span> Quay lại</a>
        <h2><?php echo e($articles->title); ?></h2>
        <p><?php echo e($articles->content); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>