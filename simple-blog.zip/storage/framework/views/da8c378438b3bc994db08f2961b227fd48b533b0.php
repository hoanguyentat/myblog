<?php $__env->startSection('head.title'); ?>
    Thêm bài viết mới
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.content'); ?>
        <form action="<?php echo e(route('articles.store')); ?>" method="POST" role="form">
        	<input type="hidden" name="_token" value="csrf_token()">
        	<?php if(count($errors) > 0): ?>
				<div class="alert alert-danger">
					<strong>Có lỗi xảy ra:</strong></br>
					<ul>
						<?php foreach($errors->all() as $error): ?>	 
							<li><?php echo e($error); ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>
        	<div class="form-group">
        		<label for="">Tiêu đề</label>
        		<input type="text" class="form-control" name="title" id="title" placeholder="Tiêu đề của bài viết">
        	</div>
        	
        	<div class="form-group">
        		<label for="">Nội dung</label>
        		<textarea style="height: 250px;" type="text" class="form-control" name="content" id="content" placeholder="Nhập nội dung bài viết"></textarea> 
        	</div>        	
        
        	<button type="submit" class="btn btn-primary">Tạo bài viết</button>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>