<?php $__env->startSection('head.title'); ?>
    Page not found
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.content'); ?>
        <h2><strong>Có lỗi xảy ra: Trang web vừa nhập không tồn tại!</strong></h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>