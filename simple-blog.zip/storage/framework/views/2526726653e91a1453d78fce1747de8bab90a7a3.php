<?php $__env->startSection('head.title'); ?>
    Thêm bài viết mới
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.content'); ?>
    	<?php if(count($errors) > 0): ?>
		<div class="alert alert-danger">
			<strong>Có lỗi xảy ra:</strong></br>
			<ul>
				<?php foreach($errors->all() as $error): ?>	 
					<li><?php echo e($error); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>

    <?php echo Form::open([
    	'route'  => 'articles.store',
    	'method' => 'POST',
    	'role'   => 'form'
    	]); ?>

    <div class="form-group">
    	<?php echo Form::label('title','Tiêu đề'); ?>

    	<?php echo Form::text('title','', ['class' => 'form-control', 'id' => 'title', 'placeholder' => 'Nhập tiêu đề bài viết']); ?>

    </div>

       <div class="form-group">
    	<?php echo Form::label('content','Nội dung'); ?>

    	<?php echo Form::textarea('content','', ['class' => 'form-control', 'id' => 'content', 'placeholder' => 'Nhập nội dung bài viết']); ?>

    </div>
	
	<button type="submit" class="btn btn-primary">Tạo bài viết</button>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>