<footer class="form-control navbar navbar-default navbar-fixed-bottom" role="navigation" style="height: 50px">
	   <center>Copy right &copy;HolaNguyen 2016. All rights reserved. Powered by Hola.</center>
</footer>