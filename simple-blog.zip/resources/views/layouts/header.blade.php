<header>
  <div class="jumbotron" style="margin-bottom: 0px;">
    <div class="container">
      	<h1 class="header">Hola's Blog</h1>
      	<p class="header">Thỏa sức đam mê, thỏa sức sáng tạo :)) :))</p>
		<iframe src="//www.facebook.com/plugins/follow?href=https%3A%2F%2Fwww.facebook.com%2Fkevinhoa95&amp;layout=standard&amp;show_faces=true&amp;colorscheme=light&amp;width=450&amp;height=80" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:350px; height:50px;" allowTransparency="true"></iframe>
    </div>
  </div>
</header>

