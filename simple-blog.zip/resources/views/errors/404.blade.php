@extends('layouts.main')
@section('head.title')
    Page not found
@endsection
@section('body.content')
        <h2><strong>Có lỗi xảy ra: Trang web vừa nhập không tồn tại!</strong></h2>
@endsection
