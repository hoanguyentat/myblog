@extends('layouts.main')
@section('head.title')
    Trang chủ
@endsection
@section('body.content')
	<div class="panel panel-default">
        <div class="panel-heading">
            <h4>Thông tin cá nhân</h4>
        </div>
        <div class="panel-body">
        <ul>
            <li>Họ và tên: Nguyễn Tất Hòa</li>
            <li>Ngày sinh: 08/07/1995</li>
            <li>Quê quán: An Đồng - Quỳnh Phụ - Thái Bình</li>
            <li>Giới tính: Nam</li>
            <li>Nơi công tác: Trường đại học Bách Khoa Hà Nội</li>
            <li>Email: kevinhoa95@gmail.com</li>
        </ul>
        </div>
    </div>
@endsection